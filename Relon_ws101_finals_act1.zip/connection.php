<?php

$db_server = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "ws101";


$conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);


//create 
$sql = 'INSERT INTO `users`(`FN`, `LN`, `DOB`, `Email`, `Password`, `Country`) VALUES ("admin","admin","2004-11-29","email@gmail.com","wertyuiop","ph")';
mysqli_query($conn, $sql);


//read
$sql = 'SELECT * FROM users';
$res = mysqli_query($conn, $sql);

echo "<h1>datas</h1>";

echo "<ul>";

while ($row = mysqli_fetch_assoc($res)) {
    //  first last
    echo '<li>' . $row['FN'] . ' ' . $row['LN'] . '</li>';
}

echo "</ul>";

echo "wowow ang galing";

// [update]

$sql = 'UPDATE from users SET FN = "admin" WHERE FN = "admin"';
$res = mysqli_query($conn, $sql);

//delete
$sql = 'DELETE FROM users WHERE FN = "admin"';
$res = mysqli_query($conn, $sql);
